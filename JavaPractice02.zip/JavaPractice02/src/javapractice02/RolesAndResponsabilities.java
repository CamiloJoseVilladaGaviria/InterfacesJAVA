/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package javapractice02;

/**
 *
 * @author ASUS
 */
public interface RolesAndResponsabilities {
    public String Rol();
    public String Responsability();
    public double Salary();
}
