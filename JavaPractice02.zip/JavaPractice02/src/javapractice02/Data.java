/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package javapractice02;

/**
 *
 * @author ASUS
 */
public interface Data {
    public String lastName();
    public String firstName();
    public int identification();
}
