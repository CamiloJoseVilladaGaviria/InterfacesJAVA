/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javapractice02;

/**
 *
 * @author ASUS
 */
public class JavaPractice02 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        SecondEmployee obj = new SecondEmployee(); //You can switch SecondEmployee Constructor to FirstEmployee Constructor!
        String One = "LAST NAME: ";
        String Two = "FIRST NAME: ";
        String Three = "IDENTIFICATION: ";
        String Four = "ROL: ";
        String Five = "RESPONSABILITY: ";
        String Six = "SALARY: ";
        System.out.println(One + obj.lastName());
        System.out.println(Two + obj.firstName());
        System.out.println(Three + obj.identification());
        System.out.println(Four + obj.Rol());
        System.out.println(Five + obj.Responsability());
        System.out.println(Six + obj.Salary());
    }  
}
