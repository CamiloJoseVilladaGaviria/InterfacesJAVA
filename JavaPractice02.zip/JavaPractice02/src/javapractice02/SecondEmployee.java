/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javapractice02;

/**
 *
 * @author ASUS
 */
public class SecondEmployee implements Data, RolesAndResponsabilities {
    @Override
    public String lastName() {
        return "Fernandez";
    }
    
    @Override
    public String firstName() {
        return "Miguel";
    }
    
    @Override
    public int identification() {
        return 1996234554;
    }
    
    @Override
    public String Rol() {
        return "SubManager";
    }
    
    @Override
    public String Responsability() {
        return "Company Administration";
    }
    
    @Override
    public double Salary() {
        return 4500.000;
    }
}
