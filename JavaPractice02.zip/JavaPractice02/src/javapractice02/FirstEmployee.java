/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javapractice02;

/**
 *
 * @author ASUS
 */
public class FirstEmployee implements Data, RolesAndResponsabilities {
    @Override
    public String lastName() {
        return "Gonzalez";
    }
    
    @Override
    public String firstName() {
        return "Andres";
    }
    
    @Override
    public int identification() {
        return 1888776664;
    }
    
    @Override
    public String Rol() {
        return "Manager";
    }
    
    @Override
    public String Responsability() {
        return "Company Administration";
    }
    
    @Override
    public double Salary() {
        return 5500.000;
    }
}
    
    
 
    
    
